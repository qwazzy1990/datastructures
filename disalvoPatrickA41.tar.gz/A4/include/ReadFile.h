
#ifndef _READ_FILE_
#define _READ_FILE_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "BinSearchTreeAPI.h"

void readFile(FILE* FP, Tree* T);
void removeHardReturn(char x[]);









#endif
